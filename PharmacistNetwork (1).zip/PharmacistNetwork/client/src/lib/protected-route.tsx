import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";
import { useEffect, useState } from "react";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const [hasError, setHasError] = useState(false);
  
  // We need to wrap this in a try/catch because the useAuth hook might throw
  // if used outside of AuthProvider
  try {
    const { user, isLoading } = useAuth();

    if (isLoading) {
      return (
        <Route path={path}>
          <div className="flex items-center justify-center min-h-screen">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </Route>
      );
    }

    if (!user) {
      return (
        <Route path={path}>
          <Redirect to="/auth" />
        </Route>
      );
    }

    return <Route path={path} component={Component} />;
  } catch (error) {
    console.error('Error in ProtectedRoute:', error);
    
    // If there's an error, we redirect to auth page
    // This usually means the auth context is not available
    if (!hasError) {
      setHasError(true);
    }
    
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }
}
