import { BookOpenCheck } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function CECreditsPage() {
  return (
    <PlaceholderPage 
      title="Continuing Education"
      description="Track and manage your continuing education credits, find certified courses, and stay up-to-date with your professional development requirements."
      icon={<BookOpenCheck className="h-8 w-8 text-primary" />}
    />
  );
}