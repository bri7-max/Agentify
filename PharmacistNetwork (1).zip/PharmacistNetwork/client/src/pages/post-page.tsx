import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { ThumbsUp, MessageCircle, Share2, MoreHorizontal, ArrowLeft, Send } from "lucide-react";
import { Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCommentSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { PostDetails, CommentWithUser } from "@/types";
import { formatDistanceToNow } from "date-fns";
import { z } from "zod";

export default function PostPage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const postId = parseInt(id);
  
  const form = useForm({
    resolver: zodResolver(insertCommentSchema),
    defaultValues: {
      content: "",
      postId
    },
  });

  const { data: post, isLoading, error } = useQuery<PostDetails>({
    queryKey: [`/api/posts/${postId}`],
    enabled: !isNaN(postId),
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (post?.userLiked) {
        const res = await apiRequest("DELETE", `/api/posts/${postId}/likes`);
        return await res.json();
      } else {
        const res = await apiRequest("POST", `/api/posts/${postId}/likes`, { postId });
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: post?.userLiked ? "Failed to unlike" : "Failed to like",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const commentMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertCommentSchema>) => {
      const res = await apiRequest("POST", `/api/posts/${postId}/comments`, data);
      return await res.json();
    },
    onSuccess: () => {
      form.reset();
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}`] });
      toast({
        title: "Comment added",
        description: "Your comment has been posted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add comment",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleLike = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to like posts",
        variant: "destructive",
      });
      return;
    }
    
    likeMutation.mutate();
  };

  const onSubmit = (data: z.infer<typeof insertCommentSchema>) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to comment",
        variant: "destructive",
      });
      return;
    }
    
    commentMutation.mutate(data);
  };
  
  const handleBack = () => {
    if (window.history.length > 2) {
      window.history.back();
    } else {
      navigate("/");
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (error || !post) {
    return (
      <MainLayout>
        <div className="p-4 text-center">
          <h2 className="text-xl font-bold text-red-500">Error loading post</h2>
          <p className="text-neutral-600 mt-2">
            {error instanceof Error ? error.message : "The requested post could not be found"}
          </p>
          <Button onClick={handleBack} className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Go Back
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="p-4">
        <Button 
          variant="ghost" 
          size="sm" 
          className="mb-4" 
          onClick={handleBack}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Avatar>
                <AvatarImage src={post.user?.profileImage} alt={post.user?.name} />
                <AvatarFallback className="bg-primary-100 text-primary-700">
                  {post.user?.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center">
                  <span className="font-semibold text-sm">{post.user?.name}</span>
                  <Badge variant="outline" className="ml-2 bg-primary-100 text-primary-700">
                    {post.user?.specialization}
                  </Badge>
                </div>
                <p className="text-xs text-neutral-500">
                  {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                </p>
              </div>
              <Button variant="ghost" size="icon" className="ml-auto text-neutral-400 hover:text-neutral-600">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </div>
            
            <p className="text-sm text-neutral-700 mb-3">
              {post.content}
            </p>
            
            {post.imageUrl && (
              <div className="mb-3">
                <img 
                  src={post.imageUrl} 
                  alt="Post content" 
                  className="w-full rounded-lg"
                />
              </div>
            )}
            
            <div className="flex items-center justify-between text-sm text-neutral-500">
              <div className="flex items-center space-x-1">
                <span className="bg-primary-500 text-white rounded-full w-5 h-5 flex items-center justify-center">
                  <ThumbsUp className="h-3 w-3" />
                </span>
                <span>{post.likes} {post.likes === 1 ? 'like' : 'likes'}</span>
              </div>
              <div>
                <span>{post.comments.length} {post.comments.length === 1 ? 'comment' : 'comments'}</span>
              </div>
            </div>
          </CardContent>
          
          <Separator />
          
          <CardFooter className="p-0">
            <div className="flex w-full">
              <Button 
                onClick={handleLike}
                disabled={likeMutation.isPending}
                variant="ghost" 
                className={`flex-1 py-2 text-sm font-medium rounded-none ${post.userLiked ? 'text-primary-600' : 'text-neutral-600'}`}
              >
                <ThumbsUp className={`mr-2 h-4 w-4 ${post.userLiked ? 'fill-current' : ''}`} />
                Like
              </Button>
              <Button variant="ghost" className="flex-1 py-2 text-sm font-medium text-neutral-600 rounded-none">
                <MessageCircle className="mr-2 h-4 w-4" />
                Comment
              </Button>
              <Button variant="ghost" className="flex-1 py-2 text-sm font-medium text-neutral-600 rounded-none">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </CardFooter>
        </Card>
        
        <h2 className="font-semibold mb-4">Comments</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="mb-6">
            <div className="flex gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImage} alt={user?.name} />
                <AvatarFallback className="bg-primary-100 text-primary-700">
                  {user?.name?.slice(0, 2).toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 flex gap-2">
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormControl>
                        <Input
                          placeholder="Add a comment..."
                          className="bg-neutral-100"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  size="icon"
                  disabled={commentMutation.isPending || !form.getValues().content.trim()}
                >
                  {commentMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </form>
        </Form>
        
        {post.comments.length > 0 ? (
          <div className="space-y-4">
            {post.comments.map((comment: CommentWithUser) => (
              <Card key={comment.id} className="shadow-sm">
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={comment.user?.profileImage} alt={comment.user?.name} />
                      <AvatarFallback className="bg-primary-100 text-primary-700">
                        {comment.user?.name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <div className="flex items-center">
                        <span className="font-semibold text-sm">{comment.user?.name}</span>
                        <span className="text-xs text-neutral-500 ml-2">
                          {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm mt-1">{comment.content}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 bg-white rounded-lg shadow-sm">
            <MessageCircle className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
            <h3 className="text-lg font-semibold">No comments yet</h3>
            <p className="text-neutral-500 text-sm">Be the first to share your thoughts</p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
