import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Search, Users, TrendingUp, Hash } from "lucide-react";
import { PostWithUser } from "@/types";
import { User, Job, Event } from "@shared/schema";
import { Link } from "wouter";

export default function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: posts, isLoading: isLoadingPosts } = useQuery<PostWithUser[]>({
    queryKey: ["/api/posts"],
  });

  // For demonstration purposes, we'll show trending topics and people
  const trendingPeople = [
    { id: 1, name: "Dr. Sarah Johnson", specialization: "Pharm D", followers: 15243, profileImage: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=150&auto=format&fit=crop" },
    { id: 2, name: "Dr. James Williams", specialization: "M Pharm", followers: 8912, profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?q=80&w=150&auto=format&fit=crop" },
    { id: 3, name: "Dr. Maria Chen", specialization: "B Pharm", followers: 7633, profileImage: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=150&auto=format&fit=crop" },
    { id: 4, name: "Dr. Robert Smith", specialization: "Pharm D", followers: 6127, profileImage: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=150&auto=format&fit=crop" }
  ];
  
  const trendingTopics = [
    { id: 1, name: "PharmacyResearch", posts: 1243 },
    { id: 2, name: "MedicationSafety", posts: 987 },
    { id: 3, name: "ClinicalPharmacy", posts: 845 },
    { id: 4, name: "PharmacyTech", posts: 734 },
    { id: 5, name: "PatientCare", posts: 612 },
    { id: 6, name: "DrugDevelopment", posts: 574 },
    { id: 7, name: "PharmacyEducation", posts: 421 },
    { id: 8, name: "PharmacistLife", posts: 382 }
  ];

  const filteredPosts = posts?.filter(post => 
    post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.user?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.user?.specialization.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="p-4">
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
          <Input 
            placeholder="Search posts, people, or topics..." 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Tabs defaultValue="trending">
          <TabsList className="w-full grid grid-cols-2 mb-4">
            <TabsTrigger value="trending">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="people">
              <Users className="h-4 w-4 mr-2" />
              People to Follow
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="trending">
            <div className="space-y-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <Hash className="h-5 w-5 mr-2 text-primary-500" />
                    Trending Topics
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {trendingTopics.map(topic => (
                      <Badge key={topic.id} variant="outline" className="bg-neutral-100 hover:bg-neutral-200 text-neutral-700">
                        #{topic.name} ({topic.posts})
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <h3 className="font-semibold text-lg">Trending Posts</h3>
              
              {isLoadingPosts ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : searchQuery && filteredPosts?.length === 0 ? (
                <div className="text-center py-8 text-neutral-500">
                  No posts found matching "{searchQuery}"
                </div>
              ) : (
                (searchQuery ? filteredPosts : posts)?.slice(0, 5).map(post => (
                  <Card key={post.id} className="mb-4">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3 mb-3">
                        <Link href={`/profile/${post.user?.id}`}>
                          <a>
                            <Avatar>
                              <AvatarImage src={post.user?.profileImage} alt={post.user?.name} />
                              <AvatarFallback className="bg-primary-100 text-primary-700">
                                {post.user?.name.slice(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                          </a>
                        </Link>
                        <div>
                          <Link href={`/profile/${post.user?.id}`}>
                            <a className="font-semibold text-sm hover:underline">{post.user?.name}</a>
                          </Link>
                          <p className="text-xs text-neutral-500">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      
                      <p className="text-sm text-neutral-700 mb-3">
                        {post.content.length > 150 
                          ? `${post.content.substring(0, 150)}...` 
                          : post.content}
                      </p>
                      
                      <Link href={`/post/${post.id}`}>
                        <Button variant="link" className="p-0 h-auto text-secondary-500">
                          Read more
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="people">
            <div className="space-y-4">
              {trendingPeople.map(person => (
                <Card key={person.id} className="mb-4">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <Link href={`/profile/${person.id}`}>
                        <a>
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={person.profileImage} alt={person.name} />
                            <AvatarFallback className="bg-primary-100 text-primary-700">
                              {person.name.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </a>
                      </Link>
                      <div className="flex-1">
                        <Link href={`/profile/${person.id}`}>
                          <a className="font-semibold hover:underline">{person.name}</a>
                        </Link>
                        <div className="flex items-center">
                          <Badge variant="outline" className="bg-primary-100 text-primary-700 mr-2">
                            {person.specialization}
                          </Badge>
                          <span className="text-xs text-neutral-500">
                            {person.followers.toLocaleString()} followers
                          </span>
                        </div>
                      </div>
                      <Button variant="secondary" size="sm">
                        Follow
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
