import { BookOpen } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function ResourcesPage() {
  return (
    <PlaceholderPage 
      title="Pharmacy Resources"
      description="Access a comprehensive library of pharmacy resources, reference materials, and clinical guidelines."
      icon={<BookOpen className="h-8 w-8 text-primary" />}
    />
  );
}