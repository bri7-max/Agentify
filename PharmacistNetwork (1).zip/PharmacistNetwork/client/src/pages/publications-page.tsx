import { FileText } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function PublicationsPage() {
  return (
    <PlaceholderPage 
      title="Pharmacy Publications"
      description="Discover the latest research papers, journals, and publications in the field of pharmacy and pharmaceutical sciences."
      icon={<FileText className="h-8 w-8 text-primary" />}
    />
  );
}