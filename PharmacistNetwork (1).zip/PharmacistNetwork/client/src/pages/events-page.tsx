import { Calendar } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function EventsPage() {
  return (
    <PlaceholderPage 
      title="Pharmacy Events"
      description="Stay updated with the latest conferences, workshops, and networking events in the pharmaceutical industry."
      icon={<Calendar className="h-8 w-8 text-primary" />}
    />
  );
}