import { GraduationCap } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function LearningPage() {
  return (
    <PlaceholderPage 
      title="Professional Learning"
      description="Enhance your professional knowledge with specialized courses, webinars, and educational content tailored for pharmacists."
      icon={<GraduationCap className="h-8 w-8 text-primary" />}
    />
  );
}