import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, ThumbsUp, Clock, Eye, MessageSquare, ChevronLeft } from "lucide-react";
import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Link, useParams, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ForumTopic, ForumCategory, ForumReply, User } from "@shared/schema";
import { CreateReplyForm } from "@/components/forum/create-reply-form";

export default function ForumTopicPage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const topicId = parseInt(id);

  interface TopicDetails extends ForumTopic {
    user: User;
    category: ForumCategory;
    isLiked: boolean;
    likeCount: number;
  }

  interface ReplyWithDetails extends ForumReply {
    user: User;
    isLiked: boolean;
    likeCount: number;
  }

  const { data: topic, isLoading: topicLoading, error: topicError } = useQuery<TopicDetails>({
    queryKey: [`/api/forum/topics/${topicId}`],
    enabled: !isNaN(topicId),
  });

  const { data: replies, isLoading: repliesLoading, error: repliesError } = useQuery<ReplyWithDetails[]>({
    queryKey: [`/api/forum/topics/${topicId}/replies`],
    enabled: !isNaN(topicId),
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (topic?.isLiked) {
        const res = await apiRequest("DELETE", `/api/forum/likes?topic_id=${topicId}`);
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/forum/likes", { topicId });
        return res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/forum/topics/${topicId}`] });
      toast({
        title: topic?.isLiked ? "Topic unliked" : "Topic liked",
        description: topic?.isLiked 
          ? "You have removed your like from this topic." 
          : "You have liked this topic.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const likeReplyMutation = useMutation({
    mutationFn: async (replyId: number) => {
      const reply = replies?.find(r => r.id === replyId);
      if (reply?.isLiked) {
        const res = await apiRequest("DELETE", `/api/forum/likes?reply_id=${replyId}`);
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/forum/likes", { replyId });
        return res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/forum/topics/${topicId}/replies`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const isLoading = topicLoading || repliesLoading;
  const error = topicError || repliesError;

  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto p-4">
        <div className="mb-6">
          <Skeleton className="h-8 w-3/4 mb-2" />
          <div className="flex items-center gap-2">
            <Skeleton className="h-6 w-6 rounded-full" />
            <Skeleton className="h-4 w-40" />
          </div>
        </div>
        <Skeleton className="h-40 w-full mb-8" />
        <div className="space-y-4">
          <Skeleton className="h-6 w-32 mb-2" />
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="mb-4">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-4 w-24" />
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container max-w-4xl mx-auto p-4 text-center">
        <h1 className="text-2xl font-bold text-red-500">Error</h1>
        <p className="mb-4">{(error as Error).message}</p>
        <div className="flex justify-center gap-4">
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/forum/topics/${topicId}`] })}>
            Retry
          </Button>
          <Button variant="outline" onClick={() => navigate("/forum")}>
            Back to Forum
          </Button>
        </div>
      </div>
    );
  }

  if (!topic) {
    return (
      <div className="container max-w-4xl mx-auto p-4 text-center">
        <h1 className="text-2xl font-bold">Topic Not Found</h1>
        <p className="mb-4">The topic you're looking for doesn't exist or has been removed.</p>
        <Button variant="outline" onClick={() => navigate("/forum")}>
          Back to Forum
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto p-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-4 text-sm text-muted-foreground">
        <Link href="/forum">
          <a className="hover:underline">Forum</a>
        </Link>
        <span>/</span>
        <Link href={`/forum/categories/${topic.categoryId}`}>
          <a className="hover:underline">{topic.category.name}</a>
        </Link>
        <span>/</span>
        <span className="truncate max-w-[200px]">{topic.title}</span>
      </div>

      {/* Topic */}
      <div className="mb-8">
        <div className="flex justify-between items-start mb-4">
          <h1 className="text-3xl font-bold">{topic.title}</h1>
          <div className="flex gap-2">
            <Link href={`/forum/categories/${topic.categoryId}`}>
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-1 h-4 w-4" />
                Back
              </Button>
            </Link>
          </div>
        </div>

        <div className="flex items-center gap-3 mb-4">
          <Avatar>
            <AvatarImage src={topic.user.profileImage || undefined} alt={topic.user.name} />
            <AvatarFallback>{topic.user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{topic.user.name}</div>
            <div className="text-sm text-muted-foreground">{topic.user.specialization}</div>
          </div>
          <div className="flex items-center ml-auto text-sm text-muted-foreground gap-4">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{topic.createdAt ? new Date(topic.createdAt).toLocaleDateString() : "N/A"}</span>
            </div>
            <div className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              <span>{topic.viewCount || 0} views</span>
            </div>
          </div>
        </div>

        <Card>
          <CardContent className="pt-6 pb-4">
            <div className="prose max-w-none dark:prose-invert">
              <p className="whitespace-pre-line">{topic.content}</p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t px-6 py-3">
            <div className="flex items-center gap-1 text-muted-foreground text-sm">
              <MessageSquare className="h-4 w-4" />
              <span>{replies?.length || 0} replies</span>
            </div>
            {user && (
              <Button
                variant={topic.isLiked ? "default" : "outline"}
                size="sm"
                onClick={() => likeMutation.mutate()}
                disabled={likeMutation.isPending}
                className="gap-2"
              >
                {likeMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ThumbsUp className="h-4 w-4" />
                )}
                <span>{topic.likeCount}</span>
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>

      {/* Replies */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Replies</h2>
          <Badge variant="outline">{replies?.length || 0}</Badge>
        </div>

        {replies?.length === 0 ? (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium mb-2">No replies yet</h3>
            <p className="text-muted-foreground mb-4">Be the first to reply to this topic</p>
          </div>
        ) : (
          <div className="space-y-4">
            {replies?.map((reply) => (
              <Card key={reply.id} id={`reply-${reply.id}`} className="relative">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={reply.user.profileImage || undefined} alt={reply.user.name} />
                      <AvatarFallback>{reply.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{reply.user.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {reply.createdAt ? new Date(reply.createdAt).toLocaleDateString() : "N/A"}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-line">{reply.content}</p>
                </CardContent>
                <CardFooter className="flex justify-end">
                  {user && (
                    <Button
                      variant={reply.isLiked ? "default" : "outline"}
                      size="sm"
                      onClick={() => likeReplyMutation.mutate(reply.id)}
                      disabled={likeReplyMutation.isPending}
                      className="gap-2"
                    >
                      <ThumbsUp className="h-4 w-4" />
                      <span>{reply.likeCount}</span>
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {/* Reply Form */}
        {user ? (
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4">Leave a Reply</h3>
            <CreateReplyForm
              topicId={topicId}
              onSuccess={() => {
                queryClient.invalidateQueries({ queryKey: [`/api/forum/topics/${topicId}/replies`] });
              }}
            />
          </div>
        ) : (
          <div className="mt-8 text-center p-6 border rounded-lg">
            <h3 className="text-lg font-semibold mb-2">Join the conversation</h3>
            <p className="text-muted-foreground mb-4">Sign in to leave a reply</p>
            <Link href="/auth">
              <Button>Sign In</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}