import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, MessageSquare, Plus, ThumbsUp, Eye } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger
} from "@/components/ui/sheet";
import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Link, useParams, useLocation } from "wouter";
import { ForumCategory, ForumTopic, User } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

const formSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Content must be at least 20 characters"),
  categoryId: z.number(),
});

type FormData = z.infer<typeof formSchema>;

export default function ForumCategoryPage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const categoryId = parseInt(id);

  interface TopicWithUser extends ForumTopic {
    user: User;
    replyCount: number;
    likeCount: number;
  }

  const { data: category, isLoading: categoryLoading, error: categoryError } = useQuery<ForumCategory>({
    queryKey: [`/api/forum/categories/${categoryId}`],
    enabled: !isNaN(categoryId),
  });

  // The API returns { category, topics } instead of just topics
  interface TopicsResponse {
    category: ForumCategory;
    topics: TopicWithUser[];
  }
  
  const { data: topicsData, isLoading: topicsLoading, error: topicsError } = useQuery<TopicsResponse>({
    queryKey: [`/api/forum/categories/${categoryId}/topics`],
    enabled: !isNaN(categoryId),
  });
  
  // Extract the topics array from the response
  const topics = topicsData?.topics;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      content: "",
      categoryId,
    },
  });

  const createTopicMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/forum/topics", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/forum/categories/${categoryId}/topics`] });
      toast({
        title: "Topic created",
        description: "Your topic has been created successfully.",
      });
      form.reset();
      setIsCreateOpen(false);
      // Navigate to the newly created topic
      navigate(`/forum/topics/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create topic",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createTopicMutation.mutate(data);
  };

  const isLoading = categoryLoading || topicsLoading;
  const error = categoryError || topicsError;

  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
        </div>
        <Separator className="my-4" />
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent className="pb-2">
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-5/6" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-4 w-1/4" />
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-2xl font-bold text-red-500">Error</h1>
        <p className="mb-4">{(error as Error).message}</p>
        <div className="flex justify-center gap-4">
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/forum/categories/${categoryId}`] })}>
            Retry
          </Button>
          <Button variant="outline" onClick={() => navigate("/forum")}>
            Back to Categories
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold">{category?.name}</h1>
            <Link href="/forum">
              <Button variant="ghost" size="sm">
                Back to Categories
              </Button>
            </Link>
          </div>
          <p className="text-muted-foreground mt-1">{category?.description}</p>
        </div>
        {user && (
          <Sheet open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <SheetTrigger asChild>
              <Button size="sm" className="flex gap-1">
                <Plus size={16} />
                Create New Topic
              </Button>
            </SheetTrigger>
            <SheetContent className="w-full md:max-w-md">
              <SheetHeader>
                <SheetTitle>Create New Topic</SheetTitle>
                <SheetDescription>
                  Start a new discussion in the {category?.name} category
                </SheetDescription>
              </SheetHeader>
              <div className="py-4">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Topic title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Share your thoughts, questions, or insights..."
                              className="min-h-[200px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={createTopicMutation.isPending}
                    >
                      {createTopicMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Topic"
                      )}
                    </Button>
                  </form>
                </Form>
              </div>
            </SheetContent>
          </Sheet>
        )}
      </div>

      <Separator className="my-4" />

      {topics && topics.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-2">No topics found</h2>
          <p className="text-muted-foreground mb-4">
            Be the first to start a discussion in this category
          </p>
          {user && (
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create New Topic
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {topics?.map((topic) => (
            <Link key={topic.id} href={`/forum/topics/${topic.id}`}>
              <a className="block">
                <Card className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{topic.title}</CardTitle>
                      {topic.isPinned && (
                        <Badge variant="outline" className="ml-2">Pinned</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={topic.user.profileImage || undefined} alt={topic.user.name} />
                        <AvatarFallback>{topic.user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span>{topic.user.name}</span>
                      <span>•</span>
                      <span>{topic.createdAt ? new Date(topic.createdAt).toLocaleDateString() : "N/A"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="line-clamp-2">{topic.content}</p>
                  </CardContent>
                  <CardFooter className="text-sm text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        <span>{topic.replyCount} replies</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="h-4 w-4" />
                        <span>{topic.likeCount} likes</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        <span>{topic.viewCount || 0} views</span>
                      </div>
                    </div>
                  </CardFooter>
                </Card>
              </a>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}