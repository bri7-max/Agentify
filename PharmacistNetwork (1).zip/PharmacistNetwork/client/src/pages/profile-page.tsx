import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { ProfileHeader } from "@/components/profile/profile-header";
import { ProfileAbout } from "@/components/profile/profile-about";
import { ProfileExperience } from "@/components/profile/profile-experience";
import { ProfileEducation } from "@/components/profile/profile-education";
import { ProfileSkills } from "@/components/profile/profile-skills";
import { ProfilePublications } from "@/components/profile/profile-publications";
import { PostCard } from "@/components/post-card";
import { Loader2 } from "lucide-react";
import { UserProfile, PostWithUser } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const userId = parseInt(id);

  const { data: profile, isLoading, error } = useQuery<UserProfile>({
    queryKey: [`/api/users/${userId}/profile`],
    enabled: !isNaN(userId),
  });

  useEffect(() => {
    if (isNaN(userId)) {
      toast({
        title: "Invalid Profile",
        description: "The requested profile could not be found",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [userId, navigate, toast]);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (error || !profile) {
    return (
      <MainLayout>
        <div className="p-4 text-center">
          <h2 className="text-xl font-bold text-red-500">Error loading profile</h2>
          <p className="text-neutral-600">
            {error instanceof Error ? error.message : "The requested profile could not be found"}
          </p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <ProfileHeader profileUser={profile.user} />
      
      <div className="p-4">
        <ProfileAbout bio={profile.user.bio || ""} />
        <ProfileExperience experiences={profile.experiences || []} />
        <ProfileEducation education={profile.education || []} />
        <ProfileSkills skills={profile.skills || []} />
        <ProfilePublications publications={profile.publications || []} />
        
        {profile.posts && profile.posts.length > 0 && (
          <div className="mt-4">
            <h2 className="text-lg font-semibold mb-3">Posts</h2>
            {profile.posts.map((post) => {
              // Convert the basic post to PostWithUser format
              const postWithUser: PostWithUser = {
                ...post,
                user: {
                  id: profile.user.id,
                  name: profile.user.name,
                  username: profile.user.username,
                  profileImage: profile.user.profileImage || "",
                  specialization: profile.user.specialization,
                },
                likesCount: 0, // We don't have this info from the profile endpoint
                commentsCount: 0, // We don't have this info from the profile endpoint
                userLiked: false, // We don't have this info from the profile endpoint
              };
              
              return <PostCard key={post.id} post={postWithUser} />;
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
