import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { JobCard } from "@/components/job-card";
import { Job } from "@shared/schema";
import { Loader2, Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function JobsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [jobTypeFilter, setJobTypeFilter] = useState("");
  const [experienceFilter, setExperienceFilter] = useState("");
  
  const { data: jobs, isLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  // Filter jobs based on search query and filters
  const filteredJobs = jobs?.filter(job => {
    const matchesSearch = 
      searchQuery === "" ||
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesLocation = 
      locationFilter === "" ||
      job.location.toLowerCase().includes(locationFilter.toLowerCase());
    
    const matchesJobType =
      jobTypeFilter === "" ||
      job.jobType === jobTypeFilter;
    
    const matchesExperience =
      experienceFilter === "" ||
      job.requirements.toLowerCase().includes(experienceFilter.toLowerCase());
    
    return matchesSearch && matchesLocation && matchesJobType && matchesExperience;
  });

  return (
    <MainLayout>
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">Pharmacy Job Board</h1>
        
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="mb-4 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
              <Input 
                placeholder="Search for jobs, companies..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <p className="text-sm mb-1">Location</p>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any location</SelectItem>
                    <SelectItem value="Boston">Boston, MA</SelectItem>
                    <SelectItem value="San Francisco">San Francisco, CA</SelectItem>
                    <SelectItem value="Chicago">Chicago, IL</SelectItem>
                    <SelectItem value="New York">New York, NY</SelectItem>
                    <SelectItem value="Remote">Remote</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm mb-1">Job Type</p>
                <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any type</SelectItem>
                    <SelectItem value="Full-time">Full-time</SelectItem>
                    <SelectItem value="Part-time">Part-time</SelectItem>
                    <SelectItem value="Contract">Contract</SelectItem>
                    <SelectItem value="Internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm mb-1">Experience Level</p>
                <Select value={experienceFilter} onValueChange={setExperienceFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any experience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any experience</SelectItem>
                    <SelectItem value="Entry Level">Entry Level</SelectItem>
                    <SelectItem value="1+ Year">1+ Year</SelectItem>
                    <SelectItem value="3+ Years">3+ Years</SelectItem>
                    <SelectItem value="5+ Years">5+ Years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-neutral-600">
            {filteredJobs ? `Showing ${filteredJobs.length} ${filteredJobs.length === 1 ? 'job' : 'jobs'}` : 'Loading...'}
          </div>
          
          <div className="flex space-x-2">
            <Badge variant="outline" className="bg-neutral-100 text-neutral-700">
              Newest first
            </Badge>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredJobs && filteredJobs.length > 0 ? (
          filteredJobs.map(job => (
            <JobCard key={job.id} job={job} />
          ))
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <Filter className="h-12 w-12 mx-auto text-neutral-400 mb-2" />
            <h3 className="text-xl font-semibold">No jobs found</h3>
            <p className="text-neutral-500">
              Try adjusting your search filters or check back later
            </p>
          </div>
        )}
        
        <div className="mt-4 text-center text-neutral-600 text-sm">
          Looking to post a pharmacy job?{" "}
          <Button variant="link" className="p-0 h-auto">
            Contact us
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}
