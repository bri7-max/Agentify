import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { ProfessionalFeaturesBar } from "@/components/professional-features-bar";
import { PostCard } from "@/components/post-card";
import { JobCard } from "@/components/job-card";
import { EventCard } from "@/components/event-card";
import { PostWithUser } from "@/types";
import { Job, Event } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const { data: posts, isLoading: isLoadingPosts } = useQuery<PostWithUser[]>({
    queryKey: ["/api/posts"],
  });

  const { data: jobs, isLoading: isLoadingJobs } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: events, isLoading: isLoadingEvents } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  // Define feed item types
  type FeedItem = 
    | { type: 'post'; item: PostWithUser }
    | { type: 'job'; item: Job }
    | { type: 'event'; item: Event };

  // Function to interleave posts, jobs, and events for a more interesting feed
  const getFeedItems = (): FeedItem[] => {
    if (!posts && !jobs && !events) return [];
    
    const feedItems: FeedItem[] = [];
    
    // Add posts first
    if (posts) {
      feedItems.push(...posts.map(post => ({ type: 'post', item: post })));
    }
    
    // Insert a job after every 2-3 posts
    if (jobs) {
      jobs.forEach((job, index) => {
        const position = (index + 1) * 3;
        if (position < feedItems.length) {
          feedItems.splice(position, 0, { type: 'job', item: job });
        } else {
          feedItems.push({ type: 'job', item: job });
        }
      });
    }
    
    // Insert an event after every 4-5 items
    if (events) {
      events.forEach((event, index) => {
        const position = (index + 1) * 5;
        if (position < feedItems.length) {
          feedItems.splice(position, 0, { type: 'event', item: event });
        } else {
          feedItems.push({ type: 'event', item: event });
        }
      });
    }
    
    return feedItems;
  };

  const feedItems = getFeedItems();

  return (
    <MainLayout>
      <div className="px-4 pt-4">
        <ProfessionalFeaturesBar />
      </div>
      
      <div className="px-4">
        {isLoadingPosts && isLoadingJobs && isLoadingEvents ? (
          // Show skeletons while loading
          Array(5).fill(0).map((_, index) => (
            <div key={index} className="mb-4">
              <Skeleton className="h-[300px] w-full rounded-lg" />
            </div>
          ))
        ) : (
          // Render feed items
          feedItems.map((item, index) => {
            switch (item.type) {
              case 'post':
                return <PostCard key={`post-${item.item.id}-${index}`} post={item.item} />;
              case 'job':
                return <JobCard key={`job-${item.item.id}-${index}`} job={item.item} />;
              case 'event':
                return <EventCard key={`event-${item.item.id}-${index}`} event={item.item} />;
              default:
                return null;
            }
          })
        )}
      </div>
    </MainLayout>
  );
}
