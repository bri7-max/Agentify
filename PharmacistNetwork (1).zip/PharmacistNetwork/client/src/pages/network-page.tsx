import { Users } from "lucide-react";
import PlaceholderPage from "./placeholder-page";

export default function NetworkPage() {
  return (
    <PlaceholderPage 
      title="Professional Network"
      description="Connect with fellow pharmacists, mentors, and industry professionals to expand your professional network."
      icon={<Users className="h-8 w-8 text-primary" />}
    />
  );
}