import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import ProfilePage from "@/pages/profile-page";
import ExplorePage from "@/pages/explore-page";
import JobsPage from "@/pages/jobs-page";
import PostPage from "@/pages/post-page";
import ForumPage from "@/pages/forum/forum-page";
import ForumCategoryPage from "@/pages/forum/forum-category-page";
import ForumTopicPage from "@/pages/forum/forum-topic-page";
import EventsPage from "@/pages/events-page";
import NetworkPage from "@/pages/network-page";
import ResourcesPage from "@/pages/resources-page";
import CECreditsPage from "@/pages/ce-credits-page";
import LearningPage from "@/pages/learning-page";
import PublicationsPage from "@/pages/publications-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "@/hooks/use-auth";

function AppRoutes() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/explore" component={ExplorePage} />
      <ProtectedRoute path="/jobs" component={JobsPage} />
      <ProtectedRoute path="/events" component={EventsPage} />
      <ProtectedRoute path="/network" component={NetworkPage} />
      <ProtectedRoute path="/resources" component={ResourcesPage} />
      <ProtectedRoute path="/ce-credits" component={CECreditsPage} />
      <ProtectedRoute path="/learning" component={LearningPage} />
      <ProtectedRoute path="/publications" component={PublicationsPage} />
      <ProtectedRoute path="/profile/:id" component={ProfilePage} />
      <ProtectedRoute path="/post/:id" component={PostPage} />
      <ProtectedRoute path="/forum" component={ForumPage} />
      <ProtectedRoute path="/forum/categories/:id" component={ForumCategoryPage} />
      <ProtectedRoute path="/forum/topics/:id" component={ForumTopicPage} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppRoutes />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
