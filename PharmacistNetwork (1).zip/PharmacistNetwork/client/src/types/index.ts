import { Post, User, Comment, Job, Event, Experience, Education, Skill, Publication } from "@shared/schema";

export interface PostWithUser extends Post {
  user: {
    id: number;
    name: string;
    username: string;
    profileImage: string;
    specialization: string;
  } | null;
  likesCount: number;
  commentsCount: number;
  userLiked: boolean;
}

export interface CommentWithUser extends Comment {
  user: {
    id: number;
    name: string;
    username: string;
    profileImage: string;
  } | null;
}

export interface UserProfile {
  user: Omit<User, "password">;
  posts: Post[];
  experiences: Experience[];
  education: Education[];
  skills: Skill[];
  publications: Publication[];
}

export interface PostDetails extends Post {
  user: {
    id: number;
    name: string;
    username: string;
    profileImage: string;
    specialization: string;
  } | null;
  likes: number;
  userLiked: boolean;
  comments: CommentWithUser[];
}
