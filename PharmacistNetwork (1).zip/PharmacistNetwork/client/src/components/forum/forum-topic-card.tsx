import { ForumTopic, User } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "wouter";
import { MessageSquare, Eye, ThumbsUp } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ForumTopicCardProps {
  topic: ForumTopic;
  author?: User;
  replyCount?: number;
  likeCount?: number;
}

export function ForumTopicCard({ topic, author, replyCount = 0, likeCount = 0 }: ForumTopicCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <Link href={`/forum/topic/${topic.id}`}>
      <Card className="cursor-pointer hover:bg-neutral-50 transition-colors">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{topic.title}</CardTitle>
            <div className="text-sm text-muted-foreground">
              {formatDistanceToNow(new Date(topic.createdAt || ""), { addSuffix: true })}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground line-clamp-2">{topic.content}</p>
        </CardContent>
        <CardFooter className="flex justify-between pt-2 pb-3">
          <div className="flex items-center gap-2">
            {author && (
              <div className="flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={author.profileImage || undefined} alt={author.name} />
                  <AvatarFallback>{getInitials(author.name)}</AvatarFallback>
                </Avatar>
                <span className="text-sm">{author.name}</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <ThumbsUp className="h-3.5 w-3.5" />
              <span>{likeCount}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MessageSquare className="h-3.5 w-3.5" />
              <span>{replyCount}</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Eye className="h-3.5 w-3.5" />
              <span>{topic.viewCount}</span>
            </div>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}