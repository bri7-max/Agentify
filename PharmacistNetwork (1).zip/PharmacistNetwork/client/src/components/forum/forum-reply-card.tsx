import { ForumReply, User } from "@shared/schema";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ThumbsUp } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

interface ForumReplyCardProps {
  reply: ForumReply;
  author?: User;
  likeCount: number;
  isLiked: boolean;
}

export function ForumReplyCard({ reply, author, likeCount, isLiked }: ForumReplyCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const likeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/forum/likes", {
        replyId: reply.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/topic", reply.topicId] });
      queryClient.invalidateQueries({ queryKey: ["/api/forum/replies", reply.topicId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const unlikeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/forum/likes/${reply.id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/topic", reply.topicId] });
      queryClient.invalidateQueries({ queryKey: ["/api/forum/replies", reply.topicId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLikeToggle = () => {
    if (isLiked) {
      unlikeMutation.mutate();
    } else {
      likeMutation.mutate();
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {author && (
              <>
                <Avatar>
                  <AvatarImage src={author.profileImage || undefined} alt={author.name} />
                  <AvatarFallback>{getInitials(author.name)}</AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="font-medium">{author.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {author.specialization}
                  </span>
                </div>
              </>
            )}
          </div>
          <div className="text-sm text-muted-foreground">
            {formatDistanceToNow(new Date(reply.createdAt || ""), { addSuffix: true })}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p>{reply.content}</p>
      </CardContent>
      <CardFooter className="pt-2">
        <Button 
          variant="ghost" 
          size="sm" 
          className={`gap-1 ${isLiked ? 'text-primary' : ''}`}
          onClick={handleLikeToggle}
          disabled={!user || likeMutation.isPending || unlikeMutation.isPending}
        >
          <ThumbsUp className="h-4 w-4" />
          <span>{likeCount}</span>
        </Button>
      </CardFooter>
    </Card>
  );
}