import { ForumCategory } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { MessageCircle } from "lucide-react";

interface ForumCategoryCardProps {
  category: ForumCategory;
  topicCount?: number;
}

export function ForumCategoryCard({ category, topicCount = 0 }: ForumCategoryCardProps) {
  return (
    <Link href={`/forum/category/${category.id}`}>
      <Card className="cursor-pointer hover:bg-neutral-50 transition-colors">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 text-primary rounded-full">
                <MessageCircle className="h-5 w-5" />
              </div>
              <CardTitle className="text-lg">{category.name}</CardTitle>
            </div>
            <div className="text-sm text-muted-foreground">
              {topicCount} {topicCount === 1 ? "topic" : "topics"}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <CardDescription>{category.description}</CardDescription>
        </CardContent>
      </Card>
    </Link>
  );
}