import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CalendarDays, MapPin, Users, Calendar } from "lucide-react";
import { Event } from "@shared/schema";
import { format } from "date-fns";

interface EventCardProps {
  event: Event;
}

export function EventCard({ event }: EventCardProps) {
  const formatDate = (date: Date) => {
    return format(new Date(date), "MMMM d, yyyy");
  };

  const formatDateRange = (startDate: Date, endDate?: Date | null) => {
    if (!endDate) return formatDate(startDate);
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear()) {
      return `${format(start, "MMMM d")}-${format(end, "d, yyyy")}`;
    }
    
    return `${formatDate(start)} - ${formatDate(end)}`;
  };

  return (
    <Card className="mb-4 bg-gradient-to-br from-purple-900 to-slate-900 border border-purple-800/30 shadow-xl rounded-xl overflow-hidden">
      <CardContent className="p-5">
        <div className="flex mb-3">
          <Badge className="bg-gradient-to-r from-purple-500 to-purple-700 text-white border-none flex items-center gap-1 px-3 py-1 shadow-md">
            <Calendar className="h-3.5 w-3.5" />
            <span>Upcoming Event</span>
          </Badge>
        </div>
        
        <h3 className="font-bold text-xl text-white mb-2">{event.title}</h3>
        <p className="text-sm text-purple-200 mb-4 leading-relaxed">
          {event.description}
        </p>
        
        {event.imageUrl && (
          <div className="mb-4 rounded-lg overflow-hidden shadow-lg border border-purple-600/20">
            <img 
              src={event.imageUrl || undefined} 
              alt={event.title} 
              className="w-full h-48 object-cover" 
            />
          </div>
        )}
        
        <div className="bg-gradient-to-r from-purple-900/40 to-slate-900/40 p-4 rounded-lg border border-purple-700/20 mb-5">
          <div className="flex items-center space-x-3 mb-3">
            <div className="bg-gradient-to-br from-purple-500 to-purple-700 p-2 rounded-full shadow-md">
              <CalendarDays className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-medium text-purple-200">
              {formatDateRange(event.startDate, event.endDate)}
            </span>
          </div>
          
          <div className="flex items-center space-x-3 mb-3">
            <div className="bg-gradient-to-br from-purple-500 to-purple-700 p-2 rounded-full shadow-md">
              <MapPin className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-medium text-purple-200">{event.location}</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-purple-500 to-purple-700 p-2 rounded-full shadow-md">
              <Users className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-medium text-purple-200">
              {event.attendees ?? 0} attending {(event.speakers ?? 0) > 0 && `• ${event.speakers} speakers`}
            </span>
          </div>
        </div>
        
        <div className="flex justify-center gap-4 mt-1">
          <Button className="flex flex-col items-center py-3 px-7 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white border-none rounded-xl shadow-md hover:shadow-lg transition-all">
            <span className="text-sm font-bold">Register Now</span>
          </Button>
          
          <Button variant="outline" className="flex flex-col items-center py-2 px-2 bg-purple-900/30 border-purple-700/50 text-purple-300 hover:text-purple-200 hover:bg-purple-800/50 rounded-xl">
            <div className="w-10 h-10 rounded-full flex items-center justify-center mb-1 bg-purple-700/30 hover:bg-purple-600/50 hover:scale-110 transition-all shadow-md">
              <Calendar className="h-5 w-5" />
            </div>
            <span className="text-xs font-medium">More Info</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
