import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ThumbsUp, MessageCircle, Share2, MoreHorizontal } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { PostWithUser } from "@/types";

interface PostCardProps {
  post: PostWithUser;
}

export function PostCard({ post }: PostCardProps) {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (post.userLiked) {
        const res = await apiRequest("DELETE", `/api/posts/${post.id}/likes`);
        return await res.json();
      } else {
        const res = await apiRequest("POST", `/api/posts/${post.id}/likes`, { postId: post.id });
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: (error: Error) => {
      toast({
        title: post.userLiked ? "Failed to unlike" : "Failed to like",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleLike = () => {
    if (!currentUser) {
      toast({
        title: "Authentication required",
        description: "Please log in to like posts",
        variant: "destructive",
      });
      return;
    }
    
    likeMutation.mutate();
  };

  return (
    <Card className="mb-4 bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 shadow-xl rounded-xl overflow-hidden">
      <div className="bg-gradient-to-r from-slate-900/60 to-slate-800/60 p-4">
        <div className="flex items-center space-x-3 mb-3">
          <Link href={`/profile/${post.user?.id}`}>
            <a>
              <Avatar className="border-2 border-primary/30 h-10 w-10">
                <AvatarImage src={post.user?.profileImage} alt={post.user?.name} />
                <AvatarFallback className="bg-gradient-to-br from-primary-400 to-primary-700 text-white font-bold">
                  {post.user?.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </a>
          </Link>
          <div>
            <div className="flex items-center">
              <Link href={`/profile/${post.user?.id}`}>
                <a className="font-semibold text-sm hover:underline text-slate-200">{post.user?.name}</a>
              </Link>
              <Badge variant="outline" className="ml-2 bg-gradient-to-r from-primary-500/20 to-primary-700/20 text-primary-400 border-primary-500/30 hover:bg-primary-200 hover:text-primary-800">
                {post.user?.specialization}
              </Badge>
            </div>
            <p className="text-xs text-slate-400">
              {formatDistanceToNow(new Date(post.createdAt || new Date()), { addSuffix: true })}
            </p>
          </div>
          <Button variant="ghost" size="icon" className="ml-auto text-slate-400 hover:text-slate-200">
            <MoreHorizontal className="h-5 w-5" />
          </Button>
        </div>
        
        <p className="text-sm text-slate-300 mb-4 leading-relaxed">
          {post.content}
        </p>
        
        {post.imageUrl && (
          <div className="mb-4">
            <img 
              src={post.imageUrl} 
              alt="Post content" 
              className="w-full h-64 object-cover rounded-lg shadow-md border border-slate-600/50"
            />
          </div>
        )}
        
        <div className="flex items-center justify-between text-sm text-slate-400 mt-2">
          <div className="flex items-center space-x-2">
            <span className="bg-gradient-to-r from-primary-400 to-primary-600 text-white rounded-full w-5 h-5 flex items-center justify-center shadow-md">
              <ThumbsUp className="h-3 w-3" />
            </span>
            <span>{post.likesCount} {post.likesCount === 1 ? 'like' : 'likes'}</span>
          </div>
          <div>
            <span>{post.commentsCount} {post.commentsCount === 1 ? 'comment' : 'comments'}</span>
          </div>
        </div>
      </div>
      
      <Separator className="bg-slate-700/50" />
      
      <CardFooter className="p-3 bg-gradient-to-r from-slate-800 to-slate-900 flex justify-around">
        <div className="flex justify-around w-full gap-2">
          <Button 
            onClick={handleLike}
            disabled={likeMutation.isPending}
            variant="ghost" 
            className={`flex flex-col items-center rounded-lg py-2 px-2 hover:bg-slate-700/40 transition-all ${post.userLiked ? 'text-primary-400' : 'text-slate-300'}`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-1 ${post.userLiked ? 'bg-primary-600/30' : 'bg-slate-700/60'} hover:scale-110 transition-all shadow-md`}>
              <ThumbsUp className={`h-5 w-5 ${post.userLiked ? 'fill-current' : ''}`} />
            </div>
            <span className="text-xs font-medium">Like</span>
          </Button>
          
          <Link href={`/post/${post.id}`}>
            <Button variant="ghost" className="flex flex-col items-center rounded-lg py-2 px-2 text-slate-300 hover:bg-slate-700/40 transition-all">
              <div className="w-10 h-10 rounded-full flex items-center justify-center mb-1 bg-slate-700/60 hover:bg-indigo-600/30 hover:scale-110 transition-all shadow-md">
                <MessageCircle className="h-5 w-5" />
              </div>
              <span className="text-xs font-medium">Comment</span>
            </Button>
          </Link>
          
          <Button variant="ghost" className="flex flex-col items-center rounded-lg py-2 px-2 text-slate-300 hover:bg-slate-700/40 transition-all">
            <div className="w-10 h-10 rounded-full flex items-center justify-center mb-1 bg-slate-700/60 hover:bg-green-600/30 hover:scale-110 transition-all shadow-md">
              <Share2 className="h-5 w-5" />
            </div>
            <span className="text-xs font-medium">Share</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
