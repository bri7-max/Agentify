import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bookmark, Briefcase } from "lucide-react";
import { Job } from "@shared/schema";

interface JobCardProps {
  job: Job;
}

export function JobCard({ job }: JobCardProps) {
  return (
    <Card className="mb-4 bg-gradient-to-br from-blue-900 to-slate-900 border border-blue-800/30 shadow-xl rounded-xl overflow-hidden">
      <CardContent className="p-5">
        <div className="flex mb-3">
          <Badge className="bg-gradient-to-r from-blue-500 to-blue-700 text-white border-none flex items-center gap-1 px-3 py-1 shadow-md">
            <Briefcase className="h-3.5 w-3.5" />
            <span>Job Opportunity</span>
          </Badge>
        </div>
        
        <div className="flex items-start space-x-4 mb-4">
          <div className="bg-white p-0.5 rounded-xl shadow-lg">
            <img 
              src={job.logoUrl || undefined} 
              alt={`${job.company} logo`} 
              className="w-14 h-14 rounded-lg object-cover" 
            />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-100">{job.title}</h3>
            <p className="text-sm text-blue-300 font-medium">{job.company}</p>
            <p className="text-xs text-slate-300 mt-1">
              {job.location} • Posted {new Date(job.createdAt || new Date()).toLocaleDateString()}
            </p>
            <div className="flex flex-wrap gap-1.5 mt-3">
              {job.requirements.split(',').map((req, index) => (
                <Badge key={index} variant="outline" className="bg-blue-900/40 text-blue-300 border-blue-700/50 hover:bg-blue-800/60">
                  {req.trim()}
                </Badge>
              ))}
            </div>
          </div>
        </div>
        
        <p className="text-sm text-slate-300 mb-5 leading-relaxed">
          {job.description}
        </p>
        
        <div className="flex justify-center gap-4 mt-1">
          <Button className="flex flex-col items-center py-3 px-7 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white border-none rounded-xl shadow-md hover:shadow-lg transition-all">
            <span className="text-sm font-bold">Apply Now</span>
          </Button>
          <Button variant="outline" className="flex flex-col items-center py-2 px-2 bg-blue-900/30 border-blue-700/50 text-blue-400 hover:text-blue-200 hover:bg-blue-800/50 rounded-xl">
            <div className="w-10 h-10 rounded-full flex items-center justify-center mb-1 bg-blue-700/30 hover:bg-blue-600/50 hover:scale-110 transition-all shadow-md">
              <Bookmark className="h-5 w-5" />
            </div>
            <span className="text-xs font-medium">Save</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
