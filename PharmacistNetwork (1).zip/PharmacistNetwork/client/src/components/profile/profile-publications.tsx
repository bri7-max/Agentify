import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Publication } from "@shared/schema";

interface ProfilePublicationsProps {
  publications: Publication[];
}

export function ProfilePublications({ publications }: ProfilePublicationsProps) {
  if (!publications || publications.length === 0) return null;
  
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Publications</h2>
        
        <div className="space-y-3">
          {publications.map((pub) => (
            <div key={pub.id} className="p-3 border border-neutral-200 rounded-lg">
              <h3 className="font-semibold text-sm">{pub.title}</h3>
              <p className="text-xs text-neutral-600 mt-1">{pub.journal}, {pub.year}</p>
              {pub.description && (
                <p className="text-sm text-neutral-700 mt-1">{pub.description}</p>
              )}
              {pub.url && (
                <Button variant="link" className="mt-2 p-0 h-auto text-secondary-500 text-sm font-medium">
                  <a href={pub.url} target="_blank" rel="noopener noreferrer">
                    View Publication →
                  </a>
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
