import { Card, CardContent } from "@/components/ui/card";

interface ProfileAboutProps {
  bio: string;
}

export function ProfileAbout({ bio }: ProfileAboutProps) {
  if (!bio) return null;
  
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-2">About</h2>
        <p className="text-sm text-neutral-700">{bio}</p>
      </CardContent>
    </Card>
  );
}
