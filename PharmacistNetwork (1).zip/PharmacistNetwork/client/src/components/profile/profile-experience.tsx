import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Experience } from "@shared/schema";

interface ProfileExperienceProps {
  experiences: Experience[];
}

export function ProfileExperience({ experiences }: ProfileExperienceProps) {
  if (!experiences || experiences.length === 0) return null;
  
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Experience</h2>
        
        <div className="space-y-4">
          {experiences.map((exp) => (
            <div key={exp.id} className="flex items-start space-x-3">
              <Avatar className="w-10 h-10 rounded-lg">
                <AvatarImage src={exp.logoUrl} alt={exp.company} />
                <AvatarFallback className="rounded-lg bg-primary-100 text-primary-700">
                  {exp.company.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-sm">{exp.title}</h3>
                <p className="text-xs text-neutral-600">{exp.company}</p>
                <p className="text-xs text-neutral-500">
                  {exp.startDate} - {exp.endDate || 'Present'} 
                  {exp.location && ` • ${exp.location}`}
                </p>
                {exp.description && (
                  <p className="text-sm text-neutral-700 mt-1">{exp.description}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
