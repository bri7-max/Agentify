import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Education } from "@shared/schema";

interface ProfileEducationProps {
  education: Education[];
}

export function ProfileEducation({ education }: ProfileEducationProps) {
  if (!education || education.length === 0) return null;
  
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Education</h2>
        
        <div className="space-y-4">
          {education.map((edu) => (
            <div key={edu.id} className="flex items-start space-x-3">
              <Avatar className="w-10 h-10 rounded-lg">
                <AvatarImage src={edu.logoUrl} alt={edu.institution} />
                <AvatarFallback className="rounded-lg bg-primary-100 text-primary-700">
                  {edu.institution.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-sm">{edu.institution}</h3>
                <p className="text-xs text-neutral-600">{edu.degree}</p>
                <p className="text-xs text-neutral-500">
                  {edu.startYear} - {edu.endYear || 'Present'}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
