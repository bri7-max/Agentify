import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, ArrowLeft } from "lucide-react";
import { User } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

interface ProfileHeaderProps {
  profileUser: Omit<User, "password">;
}

export function ProfileHeader({ profileUser }: ProfileHeaderProps) {
  const [location, setLocation] = useLocation();
  const { user: currentUser } = useAuth();
  
  const isCurrentUser = currentUser?.id === profileUser.id;

  const handleBack = () => {
    // Go back to previous page or to home
    if (window.history.length > 2) {
      window.history.back();
    } else {
      setLocation("/");
    }
  };

  return (
    <div className="relative">
      {/* Cover Photo */}
      <div className="h-36 bg-gradient-to-r from-primary-400 to-secondary-400 relative">
        {profileUser.coverImage && (
          <img 
            src={profileUser.coverImage} 
            alt={`${profileUser.name}'s cover`} 
            className="w-full h-full object-cover"
          />
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 left-4 bg-white bg-opacity-80 rounded-full text-neutral-700"
          onClick={handleBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Profile Info */}
      <div className="px-4 pt-12 pb-4 relative">
        {/* Profile picture */}
        <div className="absolute -top-12 left-4 rounded-full border-4 border-white shadow-md">
          <Avatar className="w-24 h-24">
            <AvatarImage src={profileUser.profileImage} alt={profileUser.name} />
            <AvatarFallback className="text-xl bg-primary-100 text-primary-700">
              {profileUser.name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </div>
        
        <div className="flex justify-end mb-4">
          {isCurrentUser ? (
            <Button>
              Edit Profile
            </Button>
          ) : (
            <>
              <Button variant="secondary">
                Connect
              </Button>
              <Button variant="outline" size="icon" className="ml-2">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </>
          )}
        </div>
        
        <h1 className="text-xl font-bold">
          {profileUser.name}
          {profileUser.specialization && (
            <span className="ml-2 text-base font-normal text-neutral-600">
              {profileUser.specialization}
            </span>
          )}
        </h1>
        
        {profileUser.bio && (
          <p className="text-sm text-neutral-600 mt-1">{profileUser.bio}</p>
        )}
        
        {profileUser.location && (
          <p className="text-sm text-neutral-500 mt-1">
            {profileUser.location} • 500+ connections
          </p>
        )}
        
        <div className="flex flex-wrap gap-2 mt-3">
          <Badge variant="outline" className="bg-primary-100 text-primary-700 hover:bg-primary-200">
            {profileUser.specialization} {profileUser.batch && `(${profileUser.batch})`}
          </Badge>
        </div>
      </div>
    </div>
  );
}
