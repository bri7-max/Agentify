import { useQuery } from "@tanstack/react-query";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  BookOpen, 
  Briefcase, 
  Calendar, 
  FileText, 
  GraduationCap, 
  Users, 
  MessageSquare,
  BookOpenCheck
} from "lucide-react";

interface FeatureButtonProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  gradientClass: string;
}

function FeatureButton({ icon, label, href, gradientClass }: FeatureButtonProps) {
  return (
    <Link href={href}>
      <div className="flex flex-col items-center space-y-2 flex-shrink-0 cursor-pointer group">
        <div className={`w-16 h-16 rounded-xl flex items-center justify-center ${gradientClass} transition-all transform group-hover:scale-105 shadow-md group-hover:shadow-lg`}>
          {icon}
        </div>
        <span className="text-xs font-medium text-slate-200 group-hover:text-white transition-colors">{label}</span>
      </div>
    </Link>
  );
}

export function ProfessionalFeaturesBar() {
  const features = [
    { 
      icon: <Briefcase className="h-7 w-7 text-white" />, 
      label: "Jobs", 
      href: "/jobs",
      gradientClass: "bg-gradient-to-br from-blue-500 to-blue-700"
    },
    { 
      icon: <Calendar className="h-7 w-7 text-white" />, 
      label: "Events", 
      href: "/events",
      gradientClass: "bg-gradient-to-br from-emerald-500 to-emerald-700" 
    },
    { 
      icon: <MessageSquare className="h-7 w-7 text-white" />, 
      label: "Forum", 
      href: "/forum",
      gradientClass: "bg-gradient-to-br from-indigo-500 to-indigo-700" 
    },
    { 
      icon: <Users className="h-7 w-7 text-white" />, 
      label: "Network", 
      href: "/network",
      gradientClass: "bg-gradient-to-br from-purple-500 to-purple-700" 
    },
    { 
      icon: <BookOpen className="h-7 w-7 text-white" />, 
      label: "Resources", 
      href: "/resources",
      gradientClass: "bg-gradient-to-br from-red-500 to-red-700" 
    },
    { 
      icon: <BookOpenCheck className="h-7 w-7 text-white" />, 
      label: "CE Credits", 
      href: "/ce-credits",
      gradientClass: "bg-gradient-to-br from-amber-500 to-amber-700" 
    },
    { 
      icon: <GraduationCap className="h-7 w-7 text-white" />, 
      label: "Learning", 
      href: "/learning",
      gradientClass: "bg-gradient-to-br from-cyan-500 to-cyan-700" 
    },
    { 
      icon: <FileText className="h-7 w-7 text-white" />, 
      label: "Publications", 
      href: "/publications",
      gradientClass: "bg-gradient-to-br from-pink-500 to-pink-700" 
    }
  ];

  return (
    <div className="bg-gradient-to-r from-slate-900 to-slate-800 py-6 px-2 mb-4 rounded-xl shadow-lg border border-slate-700">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-6 px-2">
          {features.map((feature, index) => (
            <FeatureButton 
              key={index}
              icon={feature.icon}
              label={feature.label}
              href={feature.href}
              gradientClass={feature.gradientClass}
            />
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}