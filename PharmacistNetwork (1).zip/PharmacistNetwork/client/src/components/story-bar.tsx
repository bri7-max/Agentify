import { useQuery } from "@tanstack/react-query";
import { StoryCircle } from "./story-circle";
import { User } from "@shared/schema";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

export function StoryBar() {
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: false, // For now, we'll use hardcoded data until we have an API to fetch users
  });

  // Hardcoded sample data for demonstration
  const sampleUsers = [
    { id: 1, name: "Dr. Sarah", profileImage: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=150&auto=format&fit=crop" },
    { id: 2, name: "Dr. James", profileImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?q=80&w=150&auto=format&fit=crop" },
    { id: 3, name: "PharmTech", profileImage: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=150&auto=format&fit=crop" },
    { id: 4, name: "Dr. Maria", profileImage: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=150&auto=format&fit=crop" },
    { id: 5, name: "MedSchool", profileImage: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=150&auto=format&fit=crop" }
  ];

  if (isLoading) {
    return (
      <div className="bg-white py-3 px-2 mb-2">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 px-2">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="flex flex-col items-center space-y-1 flex-shrink-0">
                <Skeleton className="w-16 h-16 rounded-full" />
                <Skeleton className="w-12 h-3" />
              </div>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
    );
  }

  return (
    <div className="bg-white py-3 px-2 mb-2">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-4 px-2">
          <StoryCircle name="Your story" isAdd={true} />
          {sampleUsers.map((user) => (
            <StoryCircle 
              key={user.id}
              id={user.id}
              image={user.profileImage}
              name={user.name}
            />
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}
