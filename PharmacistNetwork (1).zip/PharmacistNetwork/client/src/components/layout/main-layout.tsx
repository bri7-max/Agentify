import React from "react";
import { Navbar } from "./navbar";
import { BottomNavigation } from "./bottom-navigation";

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-neutral-50">
      <Navbar />
      <main className="flex-1 pb-16 mb-2">{children}</main>
      <BottomNavigation />
    </div>
  );
}
