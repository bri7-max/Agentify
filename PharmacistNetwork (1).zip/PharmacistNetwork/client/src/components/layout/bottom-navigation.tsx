import { Compass, Briefcase, User, MessageCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { CreatePostButton } from "../create-post-button";
import { useAuth } from "@/hooks/use-auth";

export function BottomNavigation() {
  const [location] = useLocation();
  const { user } = useAuth();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-indigo-900 to-purple-900 border-t border-indigo-800 px-3 py-2 z-40 shadow-lg">
      <div className="flex items-center justify-between">
        <Link href="/explore" className={`p-2 flex flex-col items-center ${isActive("/explore") ? "text-cyan-300" : "text-white/70"}`}>
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isActive("/explore") ? "bg-indigo-800" : "bg-indigo-800/50"} mb-1 transition-all hover:bg-indigo-700`}>
            <Compass className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium">Explore</span>
        </Link>
        
        <Link href="/forum" className={`p-2 flex flex-col items-center ${location.startsWith("/forum") ? "text-cyan-300" : "text-white/70"}`}>
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${location.startsWith("/forum") ? "bg-indigo-800" : "bg-indigo-800/50"} mb-1 transition-all hover:bg-indigo-700`}>
            <MessageCircle className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium">Forum</span>
        </Link>
        
        <div className="p-1 flex flex-col items-center">
          <CreatePostButton />
        </div>
        
        <Link href="/jobs" className={`p-2 flex flex-col items-center ${isActive("/jobs") ? "text-cyan-300" : "text-white/70"}`}>
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isActive("/jobs") ? "bg-indigo-800" : "bg-indigo-800/50"} mb-1 transition-all hover:bg-indigo-700`}>
            <Briefcase className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium">Jobs</span>
        </Link>
        
        {user && (
          <Link href={`/profile/${user.id}`} className={`p-2 flex flex-col items-center ${location.startsWith("/profile") ? "text-cyan-300" : "text-white/70"}`}>
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${location.startsWith("/profile") ? "bg-indigo-800" : "bg-indigo-800/50"} mb-1 transition-all hover:bg-indigo-700`}>
              <User className="h-6 w-6" />
            </div>
            <span className="text-xs font-medium">Profile</span>
          </Link>
        )}
      </div>
    </nav>
  );
}
