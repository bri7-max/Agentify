import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus } from "lucide-react";

interface StoryCircleProps {
  id?: number;
  image?: string;
  name: string;
  isAdd?: boolean;
}

export function StoryCircle({ id, image, name, isAdd = false }: StoryCircleProps) {
  return (
    <div className="flex flex-col items-center space-y-1 flex-shrink-0">
      {isAdd ? (
        <div className="story-circle">
          <div className="w-16 h-16 rounded-full flex items-center justify-center bg-white">
            <div className="w-[58px] h-[58px] bg-neutral-100 rounded-full flex items-center justify-center">
              <Plus className="h-5 w-5 text-secondary-500" />
            </div>
          </div>
        </div>
      ) : (
        <Link href={id ? `/profile/${id}` : "#"}>
          <a className="story-circle">
            <div className="w-16 h-16 rounded-full p-[2px] bg-white">
              <Avatar className="w-full h-full">
                <AvatarImage src={image} alt={`${name}'s profile`} />
                <AvatarFallback className="bg-primary-100 text-primary-700">
                  {name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </a>
        </Link>
      )}
      <span className="text-xs font-medium">{name}</span>
    </div>
  );
}
