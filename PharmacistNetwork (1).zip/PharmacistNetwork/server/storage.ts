import { 
  users, 
  posts, 
  comments, 
  likes, 
  jobs, 
  events, 
  experience, 
  education, 
  skills, 
  publications,
  forumCategories,
  forumTopics,
  forumReplies,
  forumLikes,
  type User, 
  type InsertUser, 
  type Post, 
  type InsertPost, 
  type Comment, 
  type InsertComment, 
  type Like, 
  type InsertLike,
  type Job,
  type InsertJob,
  type Event,
  type InsertEvent,
  type Experience,
  type InsertExperience,
  type Education,
  type InsertEducation,
  type Skill,
  type InsertSkill,
  type Publication,
  type InsertPublication,
  type ForumCategory,
  type InsertForumCategory,
  type ForumTopic,
  type InsertForumTopic,
  type ForumReply,
  type InsertForumReply,
  type ForumLike,
  type InsertForumLike
} from "@shared/schema";
import session from "express-session";
import { Store } from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Post methods
  getPosts(): Promise<Post[]>;
  getPostById(id: number): Promise<Post | undefined>;
  getPostsByUserId(userId: number): Promise<Post[]>;
  createPost(post: InsertPost, userId: number): Promise<Post>;
  deletePost(id: number): Promise<boolean>;
  
  // Comment methods
  getCommentsByPostId(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment, userId: number): Promise<Comment>;
  deleteComment(id: number): Promise<boolean>;
  
  // Like methods
  getLikesByPostId(postId: number): Promise<Like[]>;
  getLikeByUserAndPost(userId: number, postId: number): Promise<Like | undefined>;
  createLike(like: InsertLike, userId: number): Promise<Like>;
  deleteLike(id: number): Promise<boolean>;
  
  // Job methods
  getJobs(): Promise<Job[]>;
  getJobById(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Event methods
  getEvents(): Promise<Event[]>;
  getEventById(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Experience methods
  getExperienceByUserId(userId: number): Promise<Experience[]>;
  createExperience(experience: InsertExperience): Promise<Experience>;
  
  // Education methods
  getEducationByUserId(userId: number): Promise<Education[]>;
  createEducation(education: InsertEducation): Promise<Education>;
  
  // Skill methods
  getSkillsByUserId(userId: number): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  
  // Publication methods
  getPublicationsByUserId(userId: number): Promise<Publication[]>;
  createPublication(publication: InsertPublication): Promise<Publication>;

  // Forum Category methods
  getForumCategories(): Promise<ForumCategory[]>;
  getForumCategoryById(id: number): Promise<ForumCategory | undefined>;
  createForumCategory(category: InsertForumCategory): Promise<ForumCategory>;

  // Forum Topic methods
  getForumTopics(): Promise<ForumTopic[]>;
  getForumTopicById(id: number): Promise<ForumTopic | undefined>;
  getForumTopicsByCategoryId(categoryId: number): Promise<ForumTopic[]>;
  updateForumTopicViews(id: number): Promise<ForumTopic | undefined>;
  createForumTopic(topic: InsertForumTopic, userId: number): Promise<ForumTopic>;

  // Forum Reply methods
  getForumRepliesByTopicId(topicId: number): Promise<ForumReply[]>;
  createForumReply(reply: InsertForumReply, userId: number): Promise<ForumReply>;

  // Forum Like methods
  getForumLikesByTopicId(topicId: number): Promise<ForumLike[]>;
  getForumLikesByReplyId(replyId: number): Promise<ForumLike[]>;
  getForumLikeByUserAndTopic(userId: number, topicId: number): Promise<ForumLike | undefined>;
  getForumLikeByUserAndReply(userId: number, replyId: number): Promise<ForumLike | undefined>;
  createForumLike(like: InsertForumLike, userId: number): Promise<ForumLike>;
  deleteForumLike(id: number): Promise<boolean>;

  // Session store
  sessionStore: Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private likes: Map<number, Like>;
  private jobs: Map<number, Job>;
  private events: Map<number, Event>;
  private experiences: Map<number, Experience>;
  private educations: Map<number, Education>;
  private skills: Map<number, Skill>;
  private publications: Map<number, Publication>;
  private forumCategories: Map<number, ForumCategory>;
  private forumTopics: Map<number, ForumTopic>;
  private forumReplies: Map<number, ForumReply>;
  private forumLikes: Map<number, ForumLike>;
  sessionStore: Store;
  
  private userIdCounter: number;
  private postIdCounter: number;
  private commentIdCounter: number;
  private likeIdCounter: number;
  private jobIdCounter: number;
  private eventIdCounter: number;
  private experienceIdCounter: number;
  private educationIdCounter: number;
  private skillIdCounter: number;
  private publicationIdCounter: number;
  private forumCategoryIdCounter: number;
  private forumTopicIdCounter: number;
  private forumReplyIdCounter: number;
  private forumLikeIdCounter: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.jobs = new Map();
    this.events = new Map();
    this.experiences = new Map();
    this.educations = new Map();
    this.skills = new Map();
    this.publications = new Map();
    this.forumCategories = new Map();
    this.forumTopics = new Map();
    this.forumReplies = new Map();
    this.forumLikes = new Map();
    
    this.userIdCounter = 1;
    this.postIdCounter = 1;
    this.commentIdCounter = 1;
    this.likeIdCounter = 1;
    this.jobIdCounter = 1;
    this.eventIdCounter = 1;
    this.experienceIdCounter = 1;
    this.educationIdCounter = 1;
    this.skillIdCounter = 1;
    this.publicationIdCounter = 1;
    this.forumCategoryIdCounter = 1;
    this.forumTopicIdCounter = 1;
    this.forumReplyIdCounter = 1;
    this.forumLikeIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired sessions every 24h
    });

    // Initialize with some example data
    this.initializeJobs();
    this.initializeEvents();
    this.initializeForumCategories();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Post methods
  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt) : new Date(0);
      const dateB = b.createdAt ? new Date(b.createdAt) : new Date(0);
      return dateB.getTime() - dateA.getTime();
    });
  }

  async getPostById(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPostsByUserId(userId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt) : new Date(0);
        const dateB = b.createdAt ? new Date(b.createdAt) : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }

  async createPost(insertPost: InsertPost, userId: number): Promise<Post> {
    const id = this.postIdCounter++;
    const now = new Date();
    const post: Post = { ...insertPost, id, userId, createdAt: now };
    this.posts.set(id, post);
    return post;
  }

  async deletePost(id: number): Promise<boolean> {
    return this.posts.delete(id);
  }

  // Comment methods
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => {
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      });
  }

  async createComment(insertComment: InsertComment, userId: number): Promise<Comment> {
    const id = this.commentIdCounter++;
    const now = new Date();
    const comment: Comment = { ...insertComment, id, userId, createdAt: now };
    this.comments.set(id, comment);
    return comment;
  }

  async deleteComment(id: number): Promise<boolean> {
    return this.comments.delete(id);
  }

  // Like methods
  async getLikesByPostId(postId: number): Promise<Like[]> {
    return Array.from(this.likes.values()).filter(like => like.postId === postId);
  }

  async getLikeByUserAndPost(userId: number, postId: number): Promise<Like | undefined> {
    return Array.from(this.likes.values()).find(
      like => like.userId === userId && like.postId === postId
    );
  }

  async createLike(insertLike: InsertLike, userId: number): Promise<Like> {
    const id = this.likeIdCounter++;
    const now = new Date();
    const like: Like = { ...insertLike, id, userId, createdAt: now };
    this.likes.set(id, like);
    return like;
  }

  async deleteLike(id: number): Promise<boolean> {
    return this.likes.delete(id);
  }

  // Job methods
  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values());
  }

  async getJobById(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.jobIdCounter++;
    const now = new Date();
    const job: Job = { ...insertJob, id, createdAt: now };
    this.jobs.set(id, job);
    return job;
  }

  // Event methods
  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async getEventById(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const now = new Date();
    const event: Event = { ...insertEvent, id, createdAt: now };
    this.events.set(id, event);
    return event;
  }

  // Experience methods
  async getExperienceByUserId(userId: number): Promise<Experience[]> {
    return Array.from(this.experiences.values()).filter(exp => exp.userId === userId);
  }

  async createExperience(insertExperience: InsertExperience): Promise<Experience> {
    const id = this.experienceIdCounter++;
    const experience: Experience = { ...insertExperience, id };
    this.experiences.set(id, experience);
    return experience;
  }

  // Education methods
  async getEducationByUserId(userId: number): Promise<Education[]> {
    return Array.from(this.educations.values()).filter(edu => edu.userId === userId);
  }

  async createEducation(insertEducation: InsertEducation): Promise<Education> {
    const id = this.educationIdCounter++;
    const education: Education = { ...insertEducation, id };
    this.educations.set(id, education);
    return education;
  }

  // Skill methods
  async getSkillsByUserId(userId: number): Promise<Skill[]> {
    return Array.from(this.skills.values()).filter(skill => skill.userId === userId);
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = this.skillIdCounter++;
    const skill: Skill = { ...insertSkill, id };
    this.skills.set(id, skill);
    return skill;
  }

  // Publication methods
  async getPublicationsByUserId(userId: number): Promise<Publication[]> {
    return Array.from(this.publications.values()).filter(pub => pub.userId === userId);
  }

  async createPublication(insertPublication: InsertPublication): Promise<Publication> {
    const id = this.publicationIdCounter++;
    const publication: Publication = { ...insertPublication, id };
    this.publications.set(id, publication);
    return publication;
  }

  // Forum Category methods
  async getForumCategories(): Promise<ForumCategory[]> {
    return Array.from(this.forumCategories.values());
  }

  async getForumCategoryById(id: number): Promise<ForumCategory | undefined> {
    return this.forumCategories.get(id);
  }

  async createForumCategory(category: InsertForumCategory): Promise<ForumCategory> {
    const id = this.forumCategoryIdCounter++;
    const now = new Date();
    const forumCategory: ForumCategory = { ...category, id, createdAt: now };
    this.forumCategories.set(id, forumCategory);
    return forumCategory;
  }

  // Forum Topic methods
  async getForumTopics(): Promise<ForumTopic[]> {
    return Array.from(this.forumTopics.values()).sort((a, b) => {
      // Pinned topics should appear first
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      // Then sort by most recent
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async getForumTopicById(id: number): Promise<ForumTopic | undefined> {
    return this.forumTopics.get(id);
  }

  async getForumTopicsByCategoryId(categoryId: number): Promise<ForumTopic[]> {
    return Array.from(this.forumTopics.values())
      .filter(topic => topic.categoryId === categoryId)
      .sort((a, b) => {
        // Pinned topics should appear first
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        // Then sort by most recent
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }

  async updateForumTopicViews(id: number): Promise<ForumTopic | undefined> {
    const topic = this.forumTopics.get(id);
    if (!topic) return undefined;
    
    const updatedTopic: ForumTopic = { 
      ...topic, 
      viewCount: topic.viewCount + 1,
      updatedAt: new Date()
    };
    this.forumTopics.set(id, updatedTopic);
    return updatedTopic;
  }

  async createForumTopic(topic: InsertForumTopic, userId: number): Promise<ForumTopic> {
    const id = this.forumTopicIdCounter++;
    const now = new Date();
    const forumTopic: ForumTopic = { 
      ...topic, 
      id, 
      userId, 
      isPinned: false,
      viewCount: 0,
      createdAt: now,
      updatedAt: now
    };
    this.forumTopics.set(id, forumTopic);
    return forumTopic;
  }

  // Forum Reply methods
  async getForumRepliesByTopicId(topicId: number): Promise<ForumReply[]> {
    return Array.from(this.forumReplies.values())
      .filter(reply => reply.topicId === topicId)
      .sort((a, b) => {
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      });
  }

  async createForumReply(reply: InsertForumReply, userId: number): Promise<ForumReply> {
    const id = this.forumReplyIdCounter++;
    const now = new Date();
    const forumReply: ForumReply = { 
      ...reply, 
      id, 
      userId, 
      createdAt: now,
      updatedAt: now 
    };
    this.forumReplies.set(id, forumReply);
    
    // Update the topic's updated timestamp
    const topic = this.forumTopics.get(reply.topicId);
    if (topic) {
      topic.updatedAt = now;
      this.forumTopics.set(topic.id, topic);
    }
    
    return forumReply;
  }

  // Forum Like methods
  async getForumLikesByTopicId(topicId: number): Promise<ForumLike[]> {
    return Array.from(this.forumLikes.values())
      .filter(like => like.topicId === topicId);
  }

  async getForumLikesByReplyId(replyId: number): Promise<ForumLike[]> {
    return Array.from(this.forumLikes.values())
      .filter(like => like.replyId === replyId);
  }

  async getForumLikeByUserAndTopic(userId: number, topicId: number): Promise<ForumLike | undefined> {
    return Array.from(this.forumLikes.values()).find(
      like => like.userId === userId && like.topicId === topicId
    );
  }

  async getForumLikeByUserAndReply(userId: number, replyId: number): Promise<ForumLike | undefined> {
    return Array.from(this.forumLikes.values()).find(
      like => like.userId === userId && like.replyId === replyId
    );
  }

  async createForumLike(like: InsertForumLike, userId: number): Promise<ForumLike> {
    const id = this.forumLikeIdCounter++;
    const now = new Date();
    const forumLike: ForumLike = { ...like, id, userId, createdAt: now };
    this.forumLikes.set(id, forumLike);
    return forumLike;
  }

  async deleteForumLike(id: number): Promise<boolean> {
    return this.forumLikes.delete(id);
  }

  // Initialize forum categories with sample data
  private initializeForumCategories() {
    const categories: InsertForumCategory[] = [
      {
        name: "Clinical Practice",
        description: "Discuss challenges, guidelines, and best practices in clinical pharmacy.",
        iconName: "pill"
      },
      {
        name: "Medications & Therapeutics",
        description: "Information on new drugs, therapeutic approaches, and medication management.",
        iconName: "flask"
      },
      {
        name: "Regulatory & Compliance",
        description: "Updates on pharmacy laws, regulations, and compliance requirements.",
        iconName: "shield"
      },
      {
        name: "Career Development",
        description: "Discussion about career paths, certifications, and professional growth.",
        iconName: "briefcase"
      },
      {
        name: "Education & Research",
        description: "Share research findings, continuing education resources, and academic discussions.",
        iconName: "graduation-cap"
      },
      {
        name: "Technology & Innovation",
        description: "Explore new technologies, software, and innovations in pharmacy practice.",
        iconName: "cpu"
      }
    ];
    
    categories.forEach(category => {
      this.createForumCategory(category);
    });
  }

  // Initialize example data
  private initializeJobs() {
    const jobs: InsertJob[] = [
      {
        title: "Clinical Pharmacist - Oncology",
        company: "MediCorp Healthcare",
        location: "San Francisco, CA (Hybrid)",
        description: "We're seeking an experienced Clinical Pharmacist to join our Oncology department. The ideal candidate will have experience in chemotherapy protocols and patient education.",
        requirements: "Pharm D Required, 3+ Years Experience, Full-time",
        logoUrl: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?q=80&w=150&auto=format&fit=crop",
        jobType: "Full-time"
      },
      {
        title: "Staff Pharmacist",
        company: "City Hospital",
        location: "Boston, MA",
        description: "Join our team of dedicated healthcare professionals. We are looking for a licensed pharmacist to work in our inpatient pharmacy.",
        requirements: "B Pharm or Pharm D, 1+ Year Experience, Hospital Setting",
        logoUrl: "https://images.unsplash.com/photo-1631815588090-d4bfec5b1c2b?q=80&w=150&auto=format&fit=crop",
        jobType: "Full-time"
      },
      {
        title: "Pharmacy Intern",
        company: "PharmaTech Research",
        location: "Chicago, IL",
        description: "Great opportunity for pharmacy students looking to gain experience in a research setting.",
        requirements: "Currently enrolled in Pharm D program, Research interest",
        logoUrl: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?q=80&w=150&auto=format&fit=crop",
        jobType: "Internship"
      }
    ];
    
    jobs.forEach(job => {
      this.createJob(job);
    });
  }

  private initializeEvents() {
    const now = new Date();
    const futureDate1 = new Date();
    futureDate1.setMonth(futureDate1.getMonth() + 1);
    
    const futureDate2 = new Date();
    futureDate2.setMonth(futureDate2.getMonth() + 2);
    
    const events: InsertEvent[] = [
      {
        title: "Annual Pharmacy Innovation Summit",
        description: "Join leading pharmaceutical professionals for a three-day summit focused on innovation, research, and networking.",
        location: "Grand Hyatt, Boston, MA",
        imageUrl: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=600&auto=format&fit=crop",
        startDate: futureDate1,
        endDate: new Date(futureDate1.getTime() + 3 * 24 * 60 * 60 * 1000),
        attendees: 328,
        speakers: 45
      },
      {
        title: "Pharmacogenomics Masterclass",
        description: "Learn about the latest advancements in pharmacogenomics and personalized medicine.",
        location: "Online Webinar",
        imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=600&auto=format&fit=crop",
        startDate: futureDate2,
        attendees: 150,
        speakers: 3
      }
    ];
    
    events.forEach(event => {
      this.createEvent(event);
    });
  }
}

export const storage = new MemStorage();
