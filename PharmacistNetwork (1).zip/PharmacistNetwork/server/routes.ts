import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { 
  insertPostSchema, insertCommentSchema, insertLikeSchema,
  insertForumTopicSchema, insertForumReplySchema, insertForumLikeSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // User routes (beyond auth)
  app.get("/api/users/:id", async (req, res) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Filter out password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Post routes
  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getPosts();
      
      // Get user info and like counts for each post
      const postsWithDetails = await Promise.all(
        posts.map(async (post) => {
          const user = await storage.getUser(post.userId);
          const likes = await storage.getLikesByPostId(post.id);
          const comments = await storage.getCommentsByPostId(post.id);
          
          const userLiked = req.isAuthenticated() 
            ? Boolean(await storage.getLikeByUserAndPost(req.user.id, post.id)) 
            : false;
          
          return {
            ...post,
            user: user ? {
              id: user.id,
              name: user.name,
              username: user.username,
              profileImage: user.profileImage,
              specialization: user.specialization
            } : null,
            likesCount: likes.length,
            commentsCount: comments.length,
            userLiked
          };
        })
      );
      
      res.json(postsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const user = await storage.getUser(post.userId);
      const likes = await storage.getLikesByPostId(post.id);
      const comments = await storage.getCommentsByPostId(post.id);
      
      const userLiked = req.isAuthenticated() 
        ? Boolean(await storage.getLikeByUserAndPost(req.user.id, post.id)) 
        : false;
      
      const commentsWithUser = await Promise.all(
        comments.map(async (comment) => {
          const commentUser = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: commentUser ? {
              id: commentUser.id,
              name: commentUser.name,
              username: commentUser.username,
              profileImage: commentUser.profileImage
            } : null
          };
        })
      );
      
      res.json({
        ...post,
        user: user ? {
          id: user.id,
          name: user.name,
          username: user.username,
          profileImage: user.profileImage,
          specialization: user.specialization
        } : null,
        likes: likes.length,
        userLiked,
        comments: commentsWithUser
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch post details" });
    }
  });

  app.post("/api/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to create a post" });
    }

    try {
      const validatedData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(validatedData, req.user.id);
      
      // Return newly created post with user details
      const user = await storage.getUser(post.userId);
      
      res.status(201).json({
        ...post,
        user: user ? {
          id: user.id,
          name: user.name,
          username: user.username,
          profileImage: user.profileImage,
          specialization: user.specialization
        } : null,
        likesCount: 0,
        commentsCount: 0,
        userLiked: false
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.delete("/api/posts/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to delete a post" });
    }

    try {
      const postId = parseInt(req.params.id);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      if (post.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only delete your own posts" });
      }

      await storage.deletePost(postId);
      res.status(200).json({ message: "Post deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // Comment routes
  app.get("/api/posts/:postId/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.postId);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      const comments = await storage.getCommentsByPostId(postId);
      
      const commentsWithUser = await Promise.all(
        comments.map(async (comment) => {
          const user = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: user ? {
              id: user.id,
              name: user.name,
              username: user.username,
              profileImage: user.profileImage
            } : null
          };
        })
      );
      
      res.json(commentsWithUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post("/api/posts/:postId/comments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to comment" });
    }

    try {
      const postId = parseInt(req.params.postId);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const validatedData = insertCommentSchema.parse({
        ...req.body,
        postId
      });
      
      const comment = await storage.createComment(validatedData, req.user.id);
      
      // Return newly created comment with user details
      const user = await storage.getUser(comment.userId);
      
      res.status(201).json({
        ...comment,
        user: user ? {
          id: user.id,
          name: user.name,
          username: user.username,
          profileImage: user.profileImage
        } : null
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Like routes
  app.post("/api/posts/:postId/likes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to like a post" });
    }

    try {
      const postId = parseInt(req.params.postId);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      // Check if user already liked the post
      const existingLike = await storage.getLikeByUserAndPost(req.user.id, postId);
      if (existingLike) {
        return res.status(400).json({ message: "You have already liked this post" });
      }

      const validatedData = insertLikeSchema.parse({ postId });
      const like = await storage.createLike(validatedData, req.user.id);
      
      // Get updated like count
      const likes = await storage.getLikesByPostId(postId);
      
      res.status(201).json({
        like,
        count: likes.length
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to like post" });
    }
  });

  app.delete("/api/posts/:postId/likes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to unlike a post" });
    }

    try {
      const postId = parseInt(req.params.postId);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }

      // Find the user's like for this post
      const existingLike = await storage.getLikeByUserAndPost(req.user.id, postId);
      if (!existingLike) {
        return res.status(404).json({ message: "You have not liked this post" });
      }

      await storage.deleteLike(existingLike.id);
      
      // Get updated like count
      const likes = await storage.getLikesByPostId(postId);
      
      res.status(200).json({
        message: "Post unliked successfully",
        count: likes.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to unlike post" });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      if (isNaN(jobId)) {
        return res.status(400).json({ message: "Invalid job ID" });
      }

      const job = await storage.getJobById(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job details" });
    }
  });

  // Event routes
  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }

      const event = await storage.getEventById(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event details" });
    }
  });

  // Forum Category routes
  app.get("/api/forum/categories", async (req, res) => {
    try {
      const categories = await storage.getForumCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch forum categories" });
    }
  });
  
  app.post("/api/forum/categories", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to create a category" });
    }
    
    // Only admin users can create categories
    if (req.user.specialization !== "Admin") {
      return res.status(403).json({ message: "Only administrators can create categories" });
    }
    
    try {
      const category = await storage.createForumCategory(req.body);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create forum category" });
    }
  });

  app.get("/api/forum/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const category = await storage.getForumCategoryById(categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category details" });
    }
  });

  // Forum Topic routes
  app.get("/api/forum/topics", async (req, res) => {
    try {
      const topics = await storage.getForumTopics();
      
      // Get author and reply info for each topic
      const topicsWithDetails = await Promise.all(
        topics.map(async (topic) => {
          const author = await storage.getUser(topic.userId);
          const replies = await storage.getForumRepliesByTopicId(topic.id);
          const likes = await storage.getForumLikesByTopicId(topic.id);
          
          const userLiked = req.isAuthenticated() 
            ? Boolean(await storage.getForumLikeByUserAndTopic(req.user.id, topic.id)) 
            : false;
          
          return {
            ...topic,
            author: author ? {
              id: author.id,
              name: author.name,
              username: author.username,
              profileImage: author.profileImage,
              specialization: author.specialization
            } : null,
            repliesCount: replies.length,
            likesCount: likes.length,
            userLiked
          };
        })
      );
      
      res.json(topicsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch forum topics" });
    }
  });

  app.get("/api/forum/categories/:categoryId/topics", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.categoryId);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const category = await storage.getForumCategoryById(categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }

      const topics = await storage.getForumTopicsByCategoryId(categoryId);
      
      // Get author and reply info for each topic
      const topicsWithDetails = await Promise.all(
        topics.map(async (topic) => {
          const author = await storage.getUser(topic.userId);
          const replies = await storage.getForumRepliesByTopicId(topic.id);
          const likes = await storage.getForumLikesByTopicId(topic.id);
          
          const userLiked = req.isAuthenticated() 
            ? Boolean(await storage.getForumLikeByUserAndTopic(req.user.id, topic.id)) 
            : false;
          
          return {
            ...topic,
            author: author ? {
              id: author.id,
              name: author.name,
              username: author.username,
              profileImage: author.profileImage,
              specialization: author.specialization
            } : null,
            repliesCount: replies.length,
            likesCount: likes.length,
            userLiked
          };
        })
      );
      
      res.json({
        category,
        topics: topicsWithDetails
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch topics for category" });
    }
  });

  app.get("/api/forum/topics/:id", async (req, res) => {
    try {
      const topicId = parseInt(req.params.id);
      if (isNaN(topicId)) {
        return res.status(400).json({ message: "Invalid topic ID" });
      }

      // Increment view count
      const topic = await storage.updateForumTopicViews(topicId);
      if (!topic) {
        return res.status(404).json({ message: "Topic not found" });
      }

      const author = await storage.getUser(topic.userId);
      const category = await storage.getForumCategoryById(topic.categoryId);
      const replies = await storage.getForumRepliesByTopicId(topic.id);
      const likes = await storage.getForumLikesByTopicId(topic.id);
      
      const userLiked = req.isAuthenticated() 
        ? Boolean(await storage.getForumLikeByUserAndTopic(req.user.id, topic.id)) 
        : false;
      
      // Get author for each reply
      const repliesWithAuthor = await Promise.all(
        replies.map(async (reply) => {
          const replyAuthor = await storage.getUser(reply.userId);
          const replyLikes = await storage.getForumLikesByReplyId(reply.id);
          
          const userLikedReply = req.isAuthenticated() 
            ? Boolean(await storage.getForumLikeByUserAndReply(req.user.id, reply.id)) 
            : false;
          
          return {
            ...reply,
            author: replyAuthor ? {
              id: replyAuthor.id,
              name: replyAuthor.name,
              username: replyAuthor.username,
              profileImage: replyAuthor.profileImage,
              specialization: replyAuthor.specialization
            } : null,
            likesCount: replyLikes.length,
            userLiked: userLikedReply
          };
        })
      );
      
      res.json({
        ...topic,
        author: author ? {
          id: author.id,
          name: author.name,
          username: author.username,
          profileImage: author.profileImage,
          specialization: author.specialization
        } : null,
        category,
        replies: repliesWithAuthor,
        likesCount: likes.length,
        userLiked
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch topic details" });
    }
  });

  app.post("/api/forum/topics", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to create a topic" });
    }

    try {
      const validatedData = insertForumTopicSchema.parse(req.body);
      
      const categoryId = validatedData.categoryId;
      const category = await storage.getForumCategoryById(categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const topic = await storage.createForumTopic(validatedData, req.user.id);
      
      // Return newly created topic with author details
      const author = await storage.getUser(topic.userId);
      
      res.status(201).json({
        ...topic,
        author: author ? {
          id: author.id,
          name: author.name,
          username: author.username,
          profileImage: author.profileImage,
          specialization: author.specialization
        } : null,
        repliesCount: 0,
        likesCount: 0,
        userLiked: false
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create topic" });
    }
  });

  // Forum Reply routes
  app.post("/api/forum/replies", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to reply" });
    }

    try {
      const validatedData = insertForumReplySchema.parse(req.body);
      
      const topicId = validatedData.topicId;
      const topic = await storage.getForumTopicById(topicId);
      if (!topic) {
        return res.status(404).json({ message: "Topic not found" });
      }
      
      const reply = await storage.createForumReply(validatedData, req.user.id);
      
      // Return newly created reply with author details
      const author = await storage.getUser(reply.userId);
      
      res.status(201).json({
        ...reply,
        author: author ? {
          id: author.id,
          name: author.name,
          username: author.username,
          profileImage: author.profileImage,
          specialization: author.specialization
        } : null,
        likesCount: 0,
        userLiked: false
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create reply" });
    }
  });

  // Forum Like routes
  app.post("/api/forum/likes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to like" });
    }

    try {
      const validatedData = insertForumLikeSchema.parse(req.body);
      
      // Check if this is a topic like or reply like
      if (validatedData.topicId) {
        const topicId = validatedData.topicId;
        const topic = await storage.getForumTopicById(topicId);
        if (!topic) {
          return res.status(404).json({ message: "Topic not found" });
        }

        // Check if user already liked the topic
        const existingLike = await storage.getForumLikeByUserAndTopic(req.user.id, topicId);
        if (existingLike) {
          return res.status(400).json({ message: "You have already liked this topic" });
        }
      } else if (validatedData.replyId) {
        const replyId = validatedData.replyId;
        // Check if user already liked the reply
        const existingLike = await storage.getForumLikeByUserAndReply(req.user.id, replyId);
        if (existingLike) {
          return res.status(400).json({ message: "You have already liked this reply" });
        }
      } else {
        return res.status(400).json({ message: "Either topicId or replyId must be provided" });
      }
      const like = await storage.createForumLike(validatedData, req.user.id);
      
      // Get updated like count
      let count = 0;
      if (validatedData.topicId) {
        const likes = await storage.getForumLikesByTopicId(validatedData.topicId);
        count = likes.length;
      } else if (validatedData.replyId) {
        const likes = await storage.getForumLikesByReplyId(validatedData.replyId);
        count = likes.length;
      }
      
      res.status(201).json({
        like,
        count
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to like topic" });
    }
  });

  app.delete("/api/forum/likes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to unlike" });
    }

    try {
      // Get query params for topic_id or reply_id
      const topicId = req.query.topic_id ? parseInt(req.query.topic_id as string) : null;
      const replyId = req.query.reply_id ? parseInt(req.query.reply_id as string) : null;
      
      if (!topicId && !replyId) {
        return res.status(400).json({ message: "Either topic_id or reply_id query parameter must be provided" });
      }
      
      let existingLike;
      let count = 0;
      
      if (topicId) {
        // Find the user's like for this topic
        existingLike = await storage.getForumLikeByUserAndTopic(req.user.id, topicId);
        if (!existingLike) {
          return res.status(404).json({ message: "You have not liked this topic" });
        }
        
        await storage.deleteForumLike(existingLike.id);
        
        // Get updated like count
        const likes = await storage.getForumLikesByTopicId(topicId);
        count = likes.length;
        
        res.status(200).json({
          message: "Topic unliked successfully",
          count
        });
      } else if (replyId) {
        // Find the user's like for this reply
        existingLike = await storage.getForumLikeByUserAndReply(req.user.id, replyId);
        if (!existingLike) {
          return res.status(404).json({ message: "You have not liked this reply" });
        }
        
        await storage.deleteForumLike(existingLike.id);
        
        // Get updated like count
        const likes = await storage.getForumLikesByReplyId(replyId);
        count = likes.length;
        
        res.status(200).json({
          message: "Reply unliked successfully",
          count
        });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to unlike" });
    }
  });

  // User Profile routes
  app.get("/api/users/:id/profile", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get user's posts
      const posts = await storage.getPostsByUserId(userId);
      
      // Get user's experiences, education, skills, publications
      const experiences = await storage.getExperienceByUserId(userId);
      const education = await storage.getEducationByUserId(userId);
      const skills = await storage.getSkillsByUserId(userId);
      const publications = await storage.getPublicationsByUserId(userId);
      
      // Filter out the password
      const { password, ...userWithoutPassword } = user;
      
      // Construct and return the full profile
      res.json({
        user: userWithoutPassword,
        posts,
        experiences,
        education,
        skills,
        publications
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
