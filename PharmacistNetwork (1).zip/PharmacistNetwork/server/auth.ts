import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Create a test user function for development
async function createTestUser() {
  const existingUser = await storage.getUserByUsername("bright");
  
  if (!existingUser) {
    console.log("Creating test user 'bright'");
    
    const hashedPassword = await hashPassword("password123");
    
    await storage.createUser({
      username: "bright",
      password: hashedPassword,
      name: "Branham Bright",
      specialization: "Clinical Pharmacist",
      batch: "2020",
      bio: "Experienced clinical pharmacist specializing in patient care and medication management.",
      location: "San Francisco, CA",
      profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      coverImage: "https://images.unsplash.com/photo-1587727924975-56873483d151?ixlib=rb-1.2.1&auto=format&fit=crop&w=1280&q=80"
    });
    
    console.log("Test user 'bright' created successfully");
  } else {
    console.log("Test user 'bright' already exists");
  }
}

export function setupAuth(app: Express) {
  // Improved session settings with better defaults
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "pharmacy-connect-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      httpOnly: true,
      secure: false, // Set to false for local development
      sameSite: 'lax',
      path: '/', // Ensure cookies are valid for all paths
    },
    name: 'pharmconnect.sid', // Custom name to avoid using the default connect.sid
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          console.log(`Authentication failed: User '${username}' not found`);
          return done(null, false, { message: "User not found" });
        }
        
        if (!(await comparePasswords(password, user.password))) {
          console.log(`Authentication failed: Invalid password for user '${username}'`);
          return done(null, false, { message: "Invalid password" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, password, name, specialization, batch, bio, location } = req.body;
      
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(password);
      
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        name,
        specialization,
        batch: batch || "",
        bio: bio || "",
        location: location || "",
        profileImage: "",
        coverImage: ""
      });

      // Filter out the password before sending back
      const { password: _, ...userWithoutPassword } = user;

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log('Login request received:', req.body);
    
    passport.authenticate("local", (err: any, user: SelectUser | false, info: any) => {
      if (err) {
        console.error('Authentication error:', err);
        return next(err);
      }
      if (!user) {
        console.log('Authentication failed:', info?.message || 'Invalid credentials');
        return res.status(401).json({ 
          message: info?.message || "Invalid credentials",
          details: "Please check that your username and password are correct."
        });
      }
      
      req.login(user, (err: Error | null | undefined) => {
        if (err) {
          console.error('Login error:', err);
          return next(err);
        }
        
        console.log('User authenticated successfully:', user.id);
        // Filter out the password before sending back
        const { password, ...userWithoutPassword } = user;
        res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
    
    // Filter out the password before sending back
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });
  
  // Create a test user for development
  createTestUser().catch(err => {
    console.error("Error creating test user:", err);
  });
}
